package com.example.jsonapp.objects

class Task {
    var userId: Int = 0
    var id: Int = 0
    var title: String? = null
    var completed: String? = null

    constructor() {}

    constructor(userId: Int, id: Int, title: String, completed: String) {
        this.userId = userId
        this.id = id
        this.title = title
        this.completed = completed
    }
}