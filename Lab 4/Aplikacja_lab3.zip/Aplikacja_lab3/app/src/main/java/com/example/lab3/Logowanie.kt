package com.example.lab3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.example.lab3.DB.DBHelper
import com.example.lab3.modal.Player

class Logowanie : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_logowanie)

        fun setRecord(dane:String) {
            val sharedScore = this.getSharedPreferences("com.example.myapplication.shared", 0)
            val edit = sharedScore.edit()
            edit.putString("score", dane)
            edit.apply()
        }

        val rejestracja_przycisk = findViewById<Button>(R.id.Rejestracja)
        val zaloguj_przycisk = findViewById<Button>(R.id.Zaloguj)
        val lista_graczy_przycisk = findViewById<Button>(R.id.WyswietlListeGraczy)
        val nazwa_uzytkownika = findViewById<EditText>(R.id.logUsername)
        val haslo = findViewById<EditText>(R.id.logPassword)

        val brakDanych = Toast.makeText(applicationContext, "Nie wprowadzono danych", Toast.LENGTH_SHORT)
        val nieprawidloweDane = Toast.makeText(applicationContext, "Login nie może zawierać znaków specjalnych", Toast.LENGTH_LONG)
        val brakGracza = Toast.makeText(applicationContext, "Nie ma gracza o podanej nazwie", Toast.LENGTH_LONG)
        val nieprawidloweHaslo = Toast.makeText(applicationContext, "Podano nieprawidłowe hasło", Toast.LENGTH_LONG)
        val zalogowano = Toast.makeText(applicationContext, "Pomyślnie zalogowano", Toast.LENGTH_LONG)


        zaloguj_przycisk.setOnClickListener {
            val db = DBHelper(this)
            if (nazwa_uzytkownika.text.toString().trim().isNotEmpty() && haslo.text.toString().trim().isNotEmpty()) {
                if (!nazwa_uzytkownika.text.matches("^[a-zA-Z0-9]*$".toRegex()) || !haslo.text.matches("^[a-zA-Z0-9]*$".toRegex())) {
                    nieprawidloweDane.show()
                } else {
                    if (db.checkPlayer(nazwa_uzytkownika.text.toString())) {
                        val player = db.getPlayer(nazwa_uzytkownika.text.toString()).split(':')
                        if (player[1]  == haslo.text.toString()) {
                            zalogowano.show()
                            var dane = player[0] + ":" + player[2]
                            setRecord(dane)
                            val i = Intent(this, MainActivity::class.java)
                            startActivity(i)
                        } else {
                            nieprawidloweHaslo.show()
                        }
                    } else {
                        brakGracza.show()
                    }
                }
            } else {
                brakDanych.show()
            }
        }

        lista_graczy_przycisk.setOnClickListener {
            val i = Intent(this, ListaGraczy::class.java)
            startActivity(i)
        }

        rejestracja_przycisk.setOnClickListener {
            val i = Intent(this, Rejestracja::class.java)
            startActivity(i)
        }
    }
}