package com.example.jsonapp.objects

class Comment {
    var postId: Int = 0
    var id: Int = 0
    var name: String? = null
    var email: String? = null
    var body: String? = null

    constructor() {}

    constructor(postId: Int, id: Int, name: String, email: String, body: String) {
        this.postId = postId
        this.id = id
        this.name = name
        this.email = email
        this.body = body
    }
}