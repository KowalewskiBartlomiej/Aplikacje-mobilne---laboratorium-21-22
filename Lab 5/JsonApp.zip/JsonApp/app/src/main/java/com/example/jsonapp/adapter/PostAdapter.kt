package com.example.jsonapp.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.example.jsonapp.R
import com.example.jsonapp.objects.Post

class PostAdapter (private val context: Context,
                   private val dataSource: ArrayList<Post>) : BaseAdapter() {
    private val inflater: LayoutInflater
            = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater

    override fun getCount(): Int {
        return dataSource.size
    }

    override fun getItem(position: Int): Any {
        return dataSource[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {

        val rowView = inflater.inflate(R.layout.post_item, parent, false)

        val postIdView = rowView.findViewById(R.id.postId) as TextView

        val postTitleView = rowView.findViewById(R.id.postTitle) as TextView

        val postBodyView = rowView.findViewById(R.id.postBody) as TextView

        val post = getItem(position) as Post

        postIdView.text = "Id: " + post.id.toString()
        postTitleView.text = "Title: " + post.title.toString()
        postBodyView.text = "Body: " + post.body.toString()

        return rowView
    }
}