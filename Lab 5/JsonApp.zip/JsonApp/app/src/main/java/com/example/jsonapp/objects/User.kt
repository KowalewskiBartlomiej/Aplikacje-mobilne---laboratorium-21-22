package com.example.jsonapp.objects

class User {
    var id: Int = 0
    var name: String? = null
    var username: String? = null
    var email: String? = null
    var tasks_number: Int = 0
    var posts_number: Int = 0

    constructor() {}

    constructor(id: Int, name: String, username: String, email: String, tasks_number: Int, posts_number: Int) {
        this.id = id
        this.name = name
        this.username = username
        this.email = email
        this.tasks_number = tasks_number
        this.posts_number = posts_number
    }
}