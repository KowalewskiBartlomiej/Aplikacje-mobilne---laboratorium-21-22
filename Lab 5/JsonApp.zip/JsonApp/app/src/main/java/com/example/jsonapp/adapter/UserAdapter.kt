package com.example.jsonapp.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.example.jsonapp.R
import com.example.jsonapp.objects.User

class UserAdapter (private val context: Context,
                    private val dataSource: ArrayList<User>) : BaseAdapter() {
    private val inflater: LayoutInflater
            = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater

    override fun getCount(): Int {
        return dataSource.size
    }

    override fun getItem(position: Int): Any {
        return dataSource[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {

        val rowView = inflater.inflate(R.layout.user_item, parent, false)

        val userNameView = rowView.findViewById(R.id.user_name) as TextView

        val userEmailView = rowView.findViewById(R.id.user_email) as TextView

        val userTaskNumberView = rowView.findViewById(R.id.user_tasksNumber) as TextView

        val userPostNumberView = rowView.findViewById(R.id.user_postsNumber) as TextView

        val user = getItem(position) as User

        userNameView.text = "Name: " + user.name + " " + user.username
        userEmailView.text = "Email: " + user.email
        userPostNumberView.text = "Posts' number: " + user.posts_number.toString()
        userTaskNumberView.text = "Tasks' number: " + user.tasks_number.toString()

        return rowView
    }
}