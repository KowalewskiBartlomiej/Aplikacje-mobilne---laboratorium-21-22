package com.example.lab3.modal

import com.example.lab3.DB.DBHelper

class Player {
    var id: Int = 0
    var nazwa: String? = null
    var haslo: String? = null
    var punkty: Int = 0

    constructor() {}

    constructor(nazwa: String, haslo: String) {
        this.nazwa = nazwa
        this.haslo = haslo
        this.punkty = 0
    }
}