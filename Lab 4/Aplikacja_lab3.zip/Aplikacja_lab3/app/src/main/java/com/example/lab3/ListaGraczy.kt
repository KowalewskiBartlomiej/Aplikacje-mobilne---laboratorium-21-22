package com.example.lab3

import PlayerAdapter
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.lab3.DB.DBHelper
import com.example.lab3.modal.Player
import java.lang.Integer.min

class ListaGraczy : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lista_graczy)

        fun createPlayersList(db:DBHelper) : ArrayList<Player> {
            val bestplayers = ArrayList<Player>()
            val players = db.allPlayers
            for (i in 0..min(players.size-1, 9)) {
                bestplayers.add(players[i])
            }
            return bestplayers
        }

        val db = DBHelper(this)

        val players = createPlayersList(db)

        val przycisk_powrot = findViewById<Button>(R.id.powrot)
        val lista = findViewById<RecyclerView>(R.id.listaRankingowa)
        val adapter = PlayerAdapter(players)

        lista.adapter = adapter
        lista.layoutManager = LinearLayoutManager(this)

        przycisk_powrot.setOnClickListener {
            super.onBackPressed()
        }


    }
}