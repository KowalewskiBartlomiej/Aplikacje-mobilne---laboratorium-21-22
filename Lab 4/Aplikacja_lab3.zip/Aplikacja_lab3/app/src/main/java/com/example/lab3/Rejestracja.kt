package com.example.lab3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.example.lab3.DB.DBHelper
import com.example.lab3.modal.Player

class Rejestracja : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rejestracja)

        fun setRecord(dane:String) {
            val sharedScore = this.getSharedPreferences("com.example.myapplication.shared", 0)
            val edit = sharedScore.edit()
            edit.putString("score", dane)
            edit.apply()
        }

        val powrot_do_logowania_przycisk = findViewById<Button>(R.id.PowrotLogowanie)
        val nazwa_uzytkownika = findViewById<EditText>(R.id.regUsername)
        val haslo = findViewById<EditText>(R.id.regPassword)
        val haslo2 = findViewById<EditText>(R.id.regPassword2)
        val zarejestruj_przycisk = findViewById<Button>(R.id.Zarejestruj)

        val brakDanych = Toast.makeText(applicationContext, "Nie wprowadzono danych", Toast.LENGTH_SHORT)
        val nieprawidloweDane = Toast.makeText(applicationContext, "Login i hasło nie mogą zawierać znaków specjalnych", Toast.LENGTH_LONG)
        val graczIstnieje = Toast.makeText(applicationContext, "Gracz o podanej nazwie istnieje", Toast.LENGTH_LONG)
        val zarejestrowano = Toast.makeText(applicationContext, "Pomyślnie zarejestrowano", Toast.LENGTH_LONG)
        val inneHasla = Toast.makeText(applicationContext, "Hasła muszą się zgadzać", Toast.LENGTH_LONG)

        zarejestruj_przycisk.setOnClickListener {
            val db = DBHelper(this)
            if (nazwa_uzytkownika.text.toString().trim().isNotEmpty() && haslo.text.toString().trim().isNotEmpty() && haslo2.text.toString().trim().isNotEmpty()) {
                if (!nazwa_uzytkownika.text.matches("^[a-zA-Z0-9]*$".toRegex()) || !haslo.text.matches("^[a-zA-Z0-9]*$".toRegex()) || !haslo2.text.matches("^[a-zA-Z0-9]*$".toRegex())) {
                    nieprawidloweDane.show()
                } else {
                    if (db.checkPlayer(nazwa_uzytkownika.text.toString())) {
                        graczIstnieje.show()
                    } else {
                        if (haslo.text.toString() == haslo2.text.toString()) {
                            var player = Player(nazwa_uzytkownika.text.toString(), haslo.text.toString())
                            db.addPlayer(player)
                            var dane = nazwa_uzytkownika.text.toString() + ":0"
                            setRecord(dane)
                            zarejestrowano.show()
                            val i = Intent(this, Logowanie::class.java)
                            startActivity(i)
                        } else {
                            inneHasla.show()
                        }
                    }
                }
            } else {
                brakDanych.show()
            }
        }

        powrot_do_logowania_przycisk.setOnClickListener {
            super.onBackPressed()
        }
    }
}