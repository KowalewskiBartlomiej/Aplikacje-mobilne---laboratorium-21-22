package com.example.lab3.DB

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.lab3.modal.Player

class DBHelper(context: Context):SQLiteOpenHelper(context,DATABASE_NAME,
    null, DATABASE_VER) {
    companion object {
        private val DATABASE_VER = 2
        private val DATABASE_NAME = "EDMTDB.db"
        //Table
        private val TABLE_NAME = "Player"
        private val COL_ID = "Id"
        private val COL_NAZWA = "Nazwa"
        private val COL_HASLO = "Haslo"
        private val COL_PUNKTY = "Punkty"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        val CREATE_TABLE_QUERY = ("CREATE TABLE $TABLE_NAME ($COL_ID INTEGER PRIMARY KEY AUTOINCREMENT, $COL_NAZWA TEXT, $COL_HASLO TEXT, $COL_PUNKTY INTEGER)")
        db!!.execSQL(CREATE_TABLE_QUERY)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db!!.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db!!)
    }

    //CRUD
    val allPlayers:List<Player>
        get(){
            val listPlayers = ArrayList<Player>()
            val selectQuery = "SELECT * FROM $TABLE_NAME ORDER BY $COL_PUNKTY DESC"
            val db = this.writableDatabase
            val cursor =  db.rawQuery(selectQuery, null)
            if(cursor.moveToFirst()){
                do {
                    val player = Player()
                    player.id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID))
                    player.nazwa = cursor.getString(cursor.getColumnIndexOrThrow(COL_NAZWA))
                    player.haslo = cursor.getString(cursor.getColumnIndexOrThrow(COL_HASLO))
                    player.punkty = cursor.getInt(cursor.getColumnIndexOrThrow(COL_PUNKTY))

                    listPlayers.add(player)
                } while (cursor.moveToNext())
            }
            db.close()
            return listPlayers
        }

    fun addPlayer(player:Player){
        val db= this.writableDatabase
        val values = ContentValues()
        values.put(COL_NAZWA, player.nazwa)
        values.put(COL_HASLO, player.haslo)
        values.put(COL_PUNKTY, 0)

        db.insert(TABLE_NAME, null, values)
        db.close()
    }

    fun updatePlayer(nazwa:String, punkty:Int) {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(COL_PUNKTY, punkty)
        // updating row
        db.update(TABLE_NAME, values, "$COL_NAZWA = ?",
            arrayOf(nazwa))
        db.close()
    }

    fun getPlayer(login:String): String {
        val selectQuery = "SELECT * FROM $TABLE_NAME WHERE $COL_NAZWA = '$login'"
        val db = this.writableDatabase
        val cursor = db.rawQuery(selectQuery, null)
        cursor.moveToFirst()
        val dane = cursor.getString(cursor.getColumnIndexOrThrow(COL_NAZWA)) + ":" + cursor.getString(cursor.getColumnIndexOrThrow(
            COL_HASLO)) + ":" + cursor.getString(cursor.getColumnIndexOrThrow(COL_PUNKTY))
        return dane
    }

    fun checkPlayer(key:String): Boolean {
        val selectQuery = "SELECT * FROM $TABLE_NAME WHERE $COL_NAZWA = '$key'"
        val db = this.writableDatabase
        val cursor = db.rawQuery(selectQuery, null)
        if (cursor.moveToFirst()){
            if(key == cursor.getString(cursor.getColumnIndexOrThrow(COL_NAZWA))) {
                return true
            }
        }
        return false
    }


}