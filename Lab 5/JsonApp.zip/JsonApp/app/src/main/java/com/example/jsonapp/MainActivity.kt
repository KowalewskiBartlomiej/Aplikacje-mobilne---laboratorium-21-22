package com.example.jsonapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView
import com.example.jsonapp.adapter.UserAdapter
import com.example.jsonapp.objects.Post
import com.example.jsonapp.objects.Task
import com.example.jsonapp.objects.User
import org.json.JSONObject
import org.json.JSONTokener
import java.net.URL

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val uzytkownicy_lista = findViewById<ListView>(R.id.usersList)

        val uzytkownicy = ArrayList<User>()
        val posty = ArrayList<Post>()
        val zadania = ArrayList<Task>()

        var czy_wszyscy = false
        var inkrementacja_liczby_postow = false

        Thread {
            run {
                var i = 1
                while (true) {
                    try {
                        val data = JSONTokener(URL("https://jsonplaceholder.typicode.com/users/$i").readText()).nextValue() as JSONObject
                        val id = data.getInt("id")
                        val name = data.getString("name")
                        val username = data.getString("username")
                        val email = data.getString("email")
                        uzytkownicy.add(User(id, name, username, email, 0, 0))
                        i++
                    } catch (e: Exception) {
                        break
                    }
                }
            }
            runOnUiThread() {
                czy_wszyscy = true
            }
        }.start()

        Thread {

            run {
                var i = 1
                while (true) {
                    try {
                        val data = JSONTokener(URL("https://jsonplaceholder.typicode.com/posts/$i").readText()).nextValue() as JSONObject
                        val uid = data.getInt("userId")
                        val id = data.getInt("id")
                        val title = data.getString("title")
                        val body = data.getString("body")
                        posty.add(Post(uid, id, title, body))
                        i++
                    } catch (e: Exception) {
                        break
                    }
                }
            }
            runOnUiThread() {
                while (!czy_wszyscy) {}
                for (post in posty) {
                    for (uzytkownik in uzytkownicy) {
                        if (post.userId == uzytkownik.id) {
                            uzytkownik.posts_number += 1
                        }
                    }
                }
                inkrementacja_liczby_postow = true
            }
        }.start()

        Thread {

            run {
                var i = 1
                while (true) {
                    try {
                        val data = JSONTokener(URL("https://jsonplaceholder.typicode.com/todos/$i").readText()).nextValue() as JSONObject
                        val uid = data.getInt("userId")
                        val id = data.getInt("id")
                        val title = data.getString("title")
                        val completed = data.getString("completed")
                        zadania.add(Task(uid, id, title, completed))
                        i++
                    } catch (e: Exception) {
                        break
                    }
                }
            }
            runOnUiThread() {
                while (!czy_wszyscy) {}
                for (zadanie in zadania) {
                    for (uzytkownik in uzytkownicy) {
                        if (zadanie.userId == uzytkownik.id) {
                            uzytkownik.tasks_number += 1
                        }
                    }
                }
                while (!inkrementacja_liczby_postow) {}
                val adapter = UserAdapter(this, uzytkownicy)
                uzytkownicy_lista.adapter = adapter
            }
        }.start()

        uzytkownicy_lista.isClickable = true

        uzytkownicy_lista.setOnItemClickListener {
            parent, view, position, id ->
                val id = uzytkownicy[position].id
                val i = Intent(this, SzczegolyUzytkownika::class.java)
                i.putExtra("id", id)
                startActivity(i)
        }

    }
}