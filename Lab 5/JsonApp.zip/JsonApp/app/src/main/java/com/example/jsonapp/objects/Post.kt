package com.example.jsonapp.objects

class Post {
    var userId: Int = 0
    var id: Int = 0
    var title: String? = null
    var body: String? = null

    constructor() {}

    constructor(userId: Int, id: Int, title: String, body: String) {
        this.userId = userId
        this.id = id
        this.title = title
        this.body = body
    }
}