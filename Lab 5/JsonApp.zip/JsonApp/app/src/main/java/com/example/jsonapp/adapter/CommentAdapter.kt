package com.example.jsonapp.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.example.jsonapp.R
import com.example.jsonapp.objects.Comment

class CommentAdapter (private val context: Context,
                      private val dataSource: ArrayList<Comment>) : BaseAdapter() {
    private val inflater: LayoutInflater
            = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater

    override fun getCount(): Int {
        return dataSource.size
    }

    override fun getItem(position: Int): Any {
        return dataSource[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {

        val rowView = inflater.inflate(R.layout.comment_item, parent, false)

        val commentIdView = rowView.findViewById(R.id.commentId) as TextView

        val commentEmailView = rowView.findViewById(R.id.commentEmail) as TextView

        val commentNameView = rowView.findViewById(R.id.commentName) as TextView

        val commentBodyView = rowView.findViewById(R.id.commentBody) as TextView

        val comment = getItem(position) as Comment

        commentIdView.text = "Id: " + comment.id.toString()
        commentEmailView.text = "Email: " + comment.email.toString()
        commentNameView.text = "Name: " + comment.name.toString()
        commentBodyView.text = "Body: " + comment.body.toString()

        return rowView
    }
}