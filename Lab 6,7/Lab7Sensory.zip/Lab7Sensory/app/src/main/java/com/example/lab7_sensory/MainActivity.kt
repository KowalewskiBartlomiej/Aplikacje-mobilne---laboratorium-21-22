package com.example.lab7_sensory

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

var tempMessage: String = "Brak odczytu"

class MainActivity : AppCompatActivity(), SensorEventListener, LocationListener {

    private lateinit var sensorManager : SensorManager
    private lateinit var locationManager : LocationManager

    private var mwilgotnosc : Sensor ?= null
    private var mcisnienie : Sensor ?= null
    private var mtemperatura : Sensor ?= null
    private var mswiatlo : Sensor ?= null
    private var mpolozenie : Sensor ?= null

    private lateinit var lokalizacja : TextView
    private lateinit var temperatura : TextView
    private lateinit var polozenie : TextView
    private lateinit var swiatlo : TextView
    private lateinit var cisnienie : TextView
    private lateinit var wilgotnosc : TextView
    private lateinit var pobierz_lokalizacje : TextView
    private lateinit var wyjscie : Button

    private val locationPermissionCode = 2

    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        createNotificationChannel()

        lokalizacja = findViewById<TextView>(R.id.Lokalizacja)
        temperatura = findViewById<TextView>(R.id.Temperatura)
        polozenie = findViewById<TextView>(R.id.Polozenie)
        swiatlo = findViewById<TextView>(R.id.Natezenie_swiatla)
        cisnienie = findViewById<TextView>(R.id.Cisnienie)
        wilgotnosc = findViewById<TextView>(R.id.Wilgotnosc)
        pobierz_lokalizacje = findViewById<TextView>(R.id.lokalizacja_przycisk)
        wyjscie = findViewById<Button>(R.id.wyjscie)

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager

        mpolozenie = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        mcisnienie = sensorManager.getDefaultSensor(Sensor.TYPE_PRESSURE)
        mwilgotnosc = sensorManager.getDefaultSensor(Sensor.TYPE_RELATIVE_HUMIDITY)
        mswiatlo = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT)
        mtemperatura = sensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE)

        sensorManager.registerListener(this, mswiatlo, SensorManager.SENSOR_DELAY_NORMAL)
        sensorManager.registerListener(this, mcisnienie, SensorManager.SENSOR_DELAY_NORMAL)
        sensorManager.registerListener(this, mtemperatura, SensorManager.SENSOR_DELAY_NORMAL)
        sensorManager.registerListener(this, mwilgotnosc, SensorManager.SENSOR_DELAY_NORMAL)
        sensorManager.registerListener(this, mpolozenie, SensorManager.SENSOR_DELAY_NORMAL)

        scheduleNotification()

        lokalizacja.setText("\t0")
        temperatura.setText("\t0")
        polozenie.setText("\t0")
        swiatlo.setText("\t0")
        cisnienie.setText("\t0")
        wilgotnosc.setText("\t0")

        pobierz_lokalizacje.setOnClickListener {
            getLocation()
        }

        wyjscie.setOnClickListener {
            super.onBackPressed()
        }
    }

    private fun createNotificationChannel(){
        val desc = "A Description of the Channel"
        val importance  = NotificationManager.IMPORTANCE_DEFAULT
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            val channel = NotificationChannel(CHANNEL_ID, CHANNEL_NAME, importance).apply {
                description = desc
            }
            val manager  = getSystemService(Context.NOTIFICATION_SERVICE)  as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    @RequiresApi(Build.VERSION_CODES.M)
    private fun scheduleNotification() {
        val intent = Intent(applicationContext, AlarmReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(applicationContext, mNotificationID, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarmManager.setRepeating(AlarmManager.RTC_WAKEUP,
            System.currentTimeMillis() ,10000,pendingIntent)
    }

    private fun getLocation() {
        if ((ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), locationPermissionCode)
        }
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 5f, this)
    }

    override fun onLocationChanged(location: Location) {
        lokalizacja.text = "\tSzerokość: " + location.latitude + "\n\tDługość: " + location.longitude
    }

    @SuppressLint("MissingSuperCall")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        if (requestCode == locationPermissionCode) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onSensorChanged(event: SensorEvent) {

        if (event?.sensor?.type == Sensor.TYPE_AMBIENT_TEMPERATURE) {
            temperatura.setText("\t" + event.values[0].toString() + " stopni Celsjusza")
            val temperatura = event.values[0]
            tempMessage = temperatura.toString()
        }

        if (event?.sensor?.type == Sensor.TYPE_RELATIVE_HUMIDITY) {
            wilgotnosc.setText("\t" + event.values[0].toString() + " %")
            Toast.makeText(this, "Zmiana wilgotności", Toast.LENGTH_SHORT).show()
        }

        if (event?.sensor?.type == Sensor.TYPE_ACCELEROMETER) {
            polozenie.setText("\tX: " + event.values[0].toString() + " Y: " + event.values[1].toString() + " Z: " + event.values[2].toString() + "\nTekst świeci się w przypadku zmiany położenia")
            if(polozenie.currentTextColor == Color.GRAY){
                polozenie.setTextColor(Color.GREEN)
            } else {
                polozenie.setTextColor(Color.GRAY)
            }
        }

        if (event?.sensor?.type == Sensor.TYPE_LIGHT) {
            swiatlo.setText("\t" + event.values[0].toString() + " lx")
            if (event.values[0] < 100) {
                Toast.makeText(this, "Niski poziom natężenia światła", Toast.LENGTH_SHORT).show()
            } else if (event.values[0] > 100 && event.values[0] < 200) {
                Toast.makeText(this, "Wysoki poziom natężenia światła", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Bardzo wysoki poziom natężenia światła", Toast.LENGTH_SHORT).show()
            }
        }

        if (event?.sensor?.type == Sensor.TYPE_PRESSURE) {
            cisnienie.setText("\t" + event.values[0].toString() + " hPa" + "\nTekst świeci się w przypadku zmiany ciśnienia")
            if(cisnienie.currentTextColor == Color.GRAY){
                cisnienie.setTextColor(Color.GREEN)
            } else {
                cisnienie.setTextColor(Color.GRAY)
            }
        }
    }

    override fun onAccuracyChanged(p0: Sensor?, p1: Int) {
        return
    }
}