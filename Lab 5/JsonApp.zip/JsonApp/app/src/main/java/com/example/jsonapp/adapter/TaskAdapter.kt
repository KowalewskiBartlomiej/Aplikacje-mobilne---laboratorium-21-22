package com.example.jsonapp.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.example.jsonapp.R
import com.example.jsonapp.objects.Task

class TaskAdapter (private val context: Context,
                   private val dataSource: ArrayList<Task>) : BaseAdapter() {
    private val inflater: LayoutInflater
            = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater

    override fun getCount(): Int {
        return dataSource.size
    }

    override fun getItem(position: Int): Any {
        return dataSource[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {

        val rowView = inflater.inflate(R.layout.task_item, parent, false)

        val taskIdView = rowView.findViewById(R.id.taskId) as TextView

        val taskTitleView = rowView.findViewById(R.id.taskTitle) as TextView

        val taskCompletedView = rowView.findViewById(R.id.taskCompleted) as TextView

        val task = getItem(position) as Task

        taskIdView.text = "Id: " + task.id.toString()
        taskTitleView.text = "Title: " + task.title.toString()
        taskCompletedView.text = "Completed: " + task.completed.toString()

        return rowView
    }
}