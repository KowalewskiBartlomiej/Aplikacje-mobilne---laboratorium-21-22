import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.lab3.R
import com.example.lab3.modal.Player

class PlayerAdapter (private val mPlayers: List<Player>) : RecyclerView.Adapter<PlayerAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val nameTextView = itemView.findViewById<TextView>(R.id.contact_name)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PlayerAdapter.ViewHolder {
        val context = parent.context
        val inflater = LayoutInflater.from(context)
        val playerView = inflater.inflate(R.layout.player_item, parent, false)
        return ViewHolder(playerView)
    }

    override fun onBindViewHolder(viewHolder: PlayerAdapter.ViewHolder, position: Int) {
        val player: Player = mPlayers.get(position)
        val textView = viewHolder.nameTextView
        val tekst = (position+1).toString() + ". " + player.nazwa.toString() + ": " + player.punkty.toString() + " pkt"
        textView.setText(tekst)
    }

    override fun getItemCount(): Int {
        return mPlayers.size
    }
}
