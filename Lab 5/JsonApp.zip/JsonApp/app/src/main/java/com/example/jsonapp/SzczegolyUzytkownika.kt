package com.example.jsonapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ListView
import com.example.jsonapp.adapter.PostAdapter
import com.example.jsonapp.adapter.TaskAdapter
import com.example.jsonapp.objects.Post
import com.example.jsonapp.objects.Task
import org.json.JSONObject
import org.json.JSONTokener
import java.net.URL

class SzczegolyUzytkownika : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_szczegoly_uzytkownika)

        val powrot = findViewById<Button>(R.id.userDetailsbackButton)

        val posty = ArrayList<Post>()
        val zadania = ArrayList<Task>()

        val posty_lista = findViewById<ListView>(R.id.postsList)
        val zadania_lista = findViewById<ListView>(R.id.todosList)

        val extras = intent.extras
        val userId = extras?.getInt("id")

        Thread {

            run {
                var i = 1
                while (true) {
                    try {
                        val data = JSONTokener(URL("https://jsonplaceholder.typicode.com/posts/$i").readText()).nextValue() as JSONObject
                        val uid = data.getInt("userId")
                        if (uid == userId) {
                            val id = data.getInt("id")
                            val title = data.getString("title")
                            val body = data.getString("body")
                            posty.add(Post(uid, id, title, body))
                        }
                        i++
                    } catch (e: Exception) {
                        break
                    }
                }
            }
            runOnUiThread() {
                val adapter = PostAdapter(this, posty)
                posty_lista.adapter = adapter
            }
        }.start()

        Thread {

            run {
                var i = 1
                while (true) {
                    try {
                        val data = JSONTokener(URL("https://jsonplaceholder.typicode.com/todos/$i").readText()).nextValue() as JSONObject
                        val uid = data.getInt("userId")
                        if (uid == userId) {
                            val id = data.getInt("id")
                            val title = data.getString("title")
                            val completed = data.getString("completed")
                            zadania.add(Task(uid, id, title, completed))
                        }
                        i++
                    } catch (e: Exception) {
                        break
                    }
                }
            }
            runOnUiThread() {
                val adapter = TaskAdapter(this, zadania)
                zadania_lista.adapter = adapter
            }
        }.start()

        posty_lista.isClickable = true
        posty_lista.setOnItemClickListener {
            parent, view, position, id ->
            val id = posty[position].id
            val i = Intent(this, SzczegolyPosta::class.java)
            i.putExtra("id", id)
            startActivity(i)
        }


        powrot.setOnClickListener {
            super.onBackPressed()
        }
    }
}