package com.example.jsonapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ListView
import com.example.jsonapp.adapter.CommentAdapter
import com.example.jsonapp.objects.Comment
import com.example.jsonapp.objects.Task
import org.json.JSONObject
import org.json.JSONTokener
import java.net.URL

class SzczegolyPosta : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_szczegoly_posta)

        val comments_back = findViewById<Button>(R.id.commentsBackbutton)
        val back_to_users = findViewById<Button>(R.id.backToUserbutton)

        val komentarze_lista = findViewById<ListView>(R.id.commentsList)
        val komentarze = ArrayList<Comment>()

        val extras = intent.extras
        val postId = extras?.getInt("id")

        Thread {

            run {
                var i = 1
                while (true) {
                    try {
                        val data = JSONTokener(URL("https://jsonplaceholder.typicode.com/comments/$i").readText()).nextValue() as JSONObject
                        val pid = data.getInt("postId")
                        if (pid == postId) {
                            val id = data.getInt("id")
                            val name = data.getString("name")
                            val email = data.getString("email")
                            val body = data.getString("body")
                            komentarze.add(Comment(postId, id, name, email, body))
                        }
                        i++
                    } catch (e: Exception) {
                        break
                    }
                }
            }
            runOnUiThread() {
                val adapter = CommentAdapter(this, komentarze)
                komentarze_lista.adapter = adapter
            }
        }.start()

        back_to_users.setOnClickListener {
            val i = Intent(this, MainActivity::class.java)
            startActivity(i)
        }

        comments_back.setOnClickListener {
            super.onBackPressed()
        }
    }
}